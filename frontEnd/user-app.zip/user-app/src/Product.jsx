import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
// import "react.tostify/dist/ReactToastify.css";
import { toast, ToastContainer } from "react-toastify";
import { useCart } from './CartContext';
const Product = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories]=useState([]);
  const navigate = useNavigate();
  const {updateCartCount} =useCart();
  const getProducts = async () => {
    try {
      const response = await fetch(`http://localhost:3000/food/getAllFoods`);
      const data = await response.json();
      console.log(13, data)
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  }
  const getCategory = async () =>{
    const response = await fetch(`http://localhost:3000/category/getAllCategory`)
    const data = await response.json()
    console.log(22, data)
    setCategories(data)
  }
  const searchByCategories= async(id)=>{
    const requestOptions = {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
  };
       const response = await fetch(`http://localhost:3000/food/getAllFoodsByCategory/${id}`, requestOptions);
        const data = await response.json();
        setProducts(data);
  }

  const searchProducts = async (keyword) => {
    if (keyword.length === 0) {
      getProducts(); 
    }
    else{
      const response = await fetch(`http://localhost:3000/food/searchFood/${keyword}`);
      const data = await response.json();
      setProducts(data);
    }  
  };

  
const handleAddToCart = async (pid) => {
 // const navigate = useNavigate(); 

  const userid = localStorage.getItem("id");

  if (!userid) {
    navigate("/login");
  } else {
    const cartData = {
      userid: userid,
      foodid: pid,
      quantity: "1",
    };
console.log(61, cartData)
    try {
      const response = await fetch("http://localhost:3000/cart/addCart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cartData),
      });
      const data = await response.json();

      if (data._id!=null) {
        toast.success("Added to cart!");
        updateCartCount();
      } else {
        toast.error(data.message || "Failed to add to cart.");
      }

    } catch (error) {
      toast.error("Server error. Please try again later.");
      console.error(error);
    }
  }
};

  useEffect(()=>{
    getProducts();
    getCategory();
  }, [])



  return (
    <div>
      <ToastContainer/>
       <div className="container-xxl py-5">
    <div className="container">
      <div className="row g-0 gx-5 align-items-end">
        <div className="col-lg-6">
          <div className="section-header text-start mb-5 wow fadeInUp" data-wow-delay="0.1s" style={{maxWidth: 500}}>
            <h1 className="display-5 mb-3">Our Products</h1>
            {/* <p>Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p> */}
          </div>
          {/* search bar for products */}
          <input
                type="text"
                className="form-control w-50 d-inline-block" placeholder="Search product..." onChange={(e) => searchProducts(e.target.value)}
          />
          <br />
          <br />
        </div>
        
        <div className="col-lg-6 text-start text-lg-end wow slideInRight" data-wow-delay="0.1s">
          <ul className="nav nav-pills d-inline-flex justify-content-end mb-5">
            <li className="nav-item me-2">
              <a  className="btn btn-outline-primary border-2 active" data-bs-toggle="pill" onClick={getProducts}>All</a>
            </li>
            {
              categories.map((c)=>
                <li className="nav-item me-2">
                <a className="btn btn-outline-primary border-2 active" data-bs-toggle="pill" onClick={(e)=> searchByCategories(c._id)}>{c.category}</a>
                </li>
              )
            } 
          </ul>
          
        </div>
      </div>
      <div className="tab-content">
        <div id="tab-1" className="tab-pane fade show p-0 active">
          <div className="row g-4">
           {
            products.map((p)=>
              <div className="col-xl-3 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                  <div className="product-item">
                    <div className="position-relative bg-light overflow-hidden">
                      <img className="img-fluid w-100" src={p.image} style={{width:'20%'}} alt />
                      <div className="bg-secondary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">New</div>
                    </div>
                    <div className="text-center p-4">
                      <a className="d-block h5 mb-2" href>{p.foodname}</a>
                      <span className="text-primary me-1">{p.price}</span>
                      <span className="text-body text-decoration-line-through">$29.00</span>
                    </div>
                    <div className="d-flex border-top">
                      <small className="w-50 text-center border-end py-2">
                        <a className="text-body" href><i className="fa fa-eye text-primary me-2" />View detail</a>
                      </small>
                      <small className="w-50 text-center py-2">
                        <button onClick={(e) => handleAddToCart(p._id)} className="text-body border-0 bg-transparent">
                          <i className="fa fa-shopping-bag text-primary me-2" />Add to cart
                        </button>
                      </small>
                    </div>
                  </div>
                </div>
            )
           }

            <div className="col-12 text-center wow fadeInUp" data-wow-delay="0.1s">
              <a className="btn btn-primary rounded-pill py-3 px-5" href>Browse More Products</a>
            </div>
          </div>
        </div>
       
       
      </div>
    </div>
  </div>
     
    </div>

  )
}

export default Product
