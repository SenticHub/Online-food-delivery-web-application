import React from 'react'

const Profile = () => {
  return (
    <div className="container-fluid pt-4 px-4">
      <div className="row vh-100 bg-secondary rounded align-items-center justify-content-center mx-0">
        <div className="col-md-6 text-center">
          <h3>This is profile page</h3>
        </div>
      </div>
    </div>
  )
}

export default Profile
